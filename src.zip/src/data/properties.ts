import type { Property, Feature, Material, Stat } from '../types/property';

export const properties: Property[] = [
  {
    id: 'villa-aurelia',
    name: 'Villa Aurelia',
    location: 'Marbella, Spain',
    price: '€8.9M',
    priceNumeric: 8900000,
    currency: 'EUR',
    type: 'Private Villa',
    bedrooms: 5,
    bathrooms: 6,
    surfaceArea: 620,
    surfaceUnit: 'm²',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=luxury%20modern%20mediterranean%20villa%20in%20marbella%20spain%20architecture%20photography%20white%20walls%20infinity%20pool%20sunset%20golden%20hour%20minimal%20clean%20lines&image_size=landscape_16_9',
    tag: 'Featured',
  },
  {
    id: 'glass-house',
    name: 'The Glass House',
    location: 'Malibu, California',
    price: '$12.5M',
    priceNumeric: 12500000,
    currency: 'USD',
    type: 'Oceanfront Estate',
    bedrooms: 6,
    bathrooms: 7,
    surfaceArea: 780,
    surfaceUnit: 'm²',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=modern%20glass%20architecture%20luxury%20home%20malibu%20cliffside%20ocean%20view%20floor%20to%20ceiling%20windows%20dramatic%20sunset%20cinematic%20lighting&image_size=landscape_16_9',
    tag: 'New',
  },
  {
    id: 'casa-noire',
    name: 'Casa Noire',
    location: 'Dubai, UAE',
    price: '$9.8M',
    priceNumeric: 9800000,
    currency: 'USD',
    type: 'Desert Residence',
    bedrooms: 5,
    bathrooms: 6,
    surfaceArea: 710,
    surfaceUnit: 'm²',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=luxury%20contemporary%20black%20architecture%20villa%20dubai%20desert%20landscape%20dramatic%20lighting%20minimal%20geometric%20design%20pool%20water%20feature&image_size=landscape_16_9',
  },
  {
    id: 'ocean-residence',
    name: 'Ocean Residence',
    location: 'Mykonos, Greece',
    price: '€6.4M',
    priceNumeric: 6400000,
    currency: 'EUR',
    type: 'Cliffside Villa',
    bedrooms: 4,
    bathrooms: 5,
    surfaceArea: 480,
    surfaceUnit: 'm²',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=greek%20island%20luxury%20villa%20mykonos%20white%20architecture%20aegean%20sea%20view%20infinity%20pool%20blue%20sky%20cycladic%20style%20modern%20minimal&image_size=landscape_16_9',
  },
];

export const features: Feature[] = [
  {
    id: 'smart-living',
    icon: 'Home',
    label: '01',
    title: 'Smart Living',
    description: 'Intelligent systems designed around the way you live — climate, security, and entertainment orchestrated seamlessly.',
  },
  {
    id: 'virtual-tours',
    icon: 'Compass',
    label: '02',
    title: 'Immersive 360° Tours',
    description: 'Explore every residence from anywhere in the world with cinematic virtual walkthroughs and drone perspectives.',
  },
  {
    id: 'architecture',
    icon: 'Building2',
    label: '03',
    title: 'Architectural Excellence',
    description: 'Exceptional materials, precise geometry and a timeless architectural language that transcends trends.',
  },
  {
    id: 'concierge',
    icon: 'Sparkles',
    label: '04',
    title: 'Private Concierge',
    description: 'Personalized service from private viewing to acquisition — discreet, dedicated and entirely bespoke.',
  },
];

export const materials: Material[] = [
  {
    id: 'stone',
    name: 'Natural Stone',
    description: 'Hand-selected marble and limestone sourced from European quarries.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=close%20up%20natural%20stone%20marble%20texture%20luxury%20interior%20detail%20veining%20warm%20lighting%20macro%20photography%20textured&image_size=square_hd',
  },
  {
    id: 'concrete',
    name: 'Architectural Concrete',
    description: 'Polished concrete with custom aggregate blends and refined finishes.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=architectural%20polished%20concrete%20wall%20texture%20detail%20soft%20diffused%20lighting%20minimal%20modern%20interior%20close%20up&image_size=square_hd',
  },
  {
    id: 'glass',
    name: 'Floor-to-Ceiling Glass',
    description: 'Thermally broken frames with triple-glazed solar-control glazing.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=floor%20to%20ceiling%20glass%20windows%20luxury%20interior%20architecture%20detail%20reflection%20natural%20light%20minimal%20clean&image_size=square_hd',
  },
  {
    id: 'wood',
    name: 'Custom Woodwork',
    description: 'Fumed oak and walnut finishes crafted by European artisans.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=custom%20dark%20oak%20wood%20paneling%20luxury%20interior%20detail%20warm%20lighting%20texture%20grain%20craftsmanship%20close%20up&image_size=square_hd',
  },
  {
    id: 'lighting',
    name: 'Integrated Lighting',
    description: 'Circadian lighting systems tuned to natural daylight patterns.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=integrated%20recessed%20architectural%20lighting%20detail%20luxury%20ceiling%20warm%20ambient%20light%20modern%20interior%20minimal&image_size=square_hd',
  },
  {
    id: 'landscape',
    name: 'Landscape Design',
    description: 'Sculpted gardens integrating native flora and water features.',
    image: 'https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=luxury%20landscape%20design%20sculpted%20garden%20water%20feature%20modern%20architecture%20greenery%20minimal%20zen%20aesthetic&image_size=square_hd',
  },
];

export const stats: Stat[] = [
  {
    id: 'residences',
    value: '14',
    label: 'Private Residences',
  },
  {
    id: 'locations',
    value: '08',
    label: 'Global Locations',
  },
  {
    id: 'portfolio',
    value: '€120M+',
    label: 'Portfolio Value',
  },
  {
    id: 'concierge',
    value: '24/7',
    label: 'Private Concierge',
  },
];

export const navLinks = [
  { label: 'Properties', href: '#properties' },
  { label: 'Architecture', href: '#architecture' },
  { label: 'Experience', href: '#experience' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];
